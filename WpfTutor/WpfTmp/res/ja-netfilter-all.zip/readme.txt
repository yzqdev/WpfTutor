License code: 
    1. add -javaagent:/path/to/ja-netfilter.jar=jetbrains to your vmoptions (manual or auto)
    2. log out of the jb account in the 'Licenses' window
    3. use key on page https://jetbra.in/5d84466e31722979266057664941a71893322460

Or

License server:
    1. add -javaagent:/path/to/ja-netfilter.jar=jetbrains to your vmoptions (manual or auto)
    2. log out of the jb account in the 'Licenses' window
    3. uninstall plugin: 'IDE Eval Reset'
    4. use license server url: https://jetbra.in

Enjoy it~


NEW: 
    Auto configure vmoptions (Copy form Neo):
    macOS or Linux: execute "scripts/install.sh"
    Windows: double click to execute "scripts\install-current-user.vbs" (For current user)
                                     "scripts\install-all-users.vbs" (For all users)
